// SectionController.java
package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.ClassAdd;
import org.example.timetablegenerator.model.Section;
import org.example.timetablegenerator.repository.ClassAddRepository;
import org.example.timetablegenerator.repository.SectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;

@Controller
public class SectionController {

    @Autowired
    private ClassAddRepository classAddRepository;

    @Autowired
    private SectionRepository sectionRepository;

    @GetMapping("/add-section")
    public String showAddSectionPage(Model model, @RequestParam(value = "successMessage", required = false) String successMessage) {
        List<ClassAdd> classes = classAddRepository.findAll();
        model.addAttribute("classes", classes);
        model.addAttribute("successMessage", successMessage);
        return "add-section";
    }

    @PostMapping("/add-section")
    public String addSection(@RequestParam("classId") Long classId,
                             @RequestParam("sectionNames") String sectionNames,
                             Model model) {
        String[] sections = sectionNames.split("\\s*,\\s*");
        ClassAdd classAdd = classAddRepository.findById(classId)
                .orElseThrow(() -> new RuntimeException("Class not found"));

        for (String sectionName : sections) {
            Section section = new Section();
            section.setSectionName(sectionName);
            section.setClassAdd(classAdd);
            sectionRepository.save(section);
        }

        model.addAttribute("successMessage", "Sections added successfully!");
        model.addAttribute("classes", classAddRepository.findAll());
        return "add-section";
    }

    // REST endpoint for frontend dropdown
    @GetMapping("/api/sections")
    @ResponseBody
    public List<String> getSectionNames() {
        return sectionRepository.findAll()
                .stream()
                .map(Section::getSectionName)
                .distinct()
                .toList();
    }
}


// Optional: IdMappingController
@RestController
@RequestMapping("/api")
class IdMappingController {

    @Autowired
    private ClassAddRepository classAddRepository;

    @Autowired
    private SectionRepository sectionRepository;

    @GetMapping("/id-mapping")
    public Map<String, Long> getIdMapping(@RequestParam String className, @RequestParam String sectionName) {
        ClassAdd classAdd = classAddRepository.findByClassName(className)
                .orElseThrow(() -> new RuntimeException("Class not found: " + className));

        Section section = sectionRepository.findBySectionNameAndClassAdd(sectionName, classAdd)
                .orElseThrow(() -> new RuntimeException("Section not found for class: " + sectionName));

        return Map.of("classId", classAdd.getId(), "sectionId", section.getId());
    }
}
