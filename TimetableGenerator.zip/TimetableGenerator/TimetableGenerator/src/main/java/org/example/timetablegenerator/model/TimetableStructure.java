package org.example.timetablegenerator.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.*;
import java.time.LocalTime;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;


@Entity
@Table(name = "timetable_structure")
public class TimetableStructure {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "start_time", nullable = false)
    private LocalTime startTime;

    @Column(name = "end_time", nullable = false)
    private LocalTime endTime;

    @Column(name = "number_of_periods", nullable = false)
    private int numberOfPeriods;

    @Column(name = "period_duration_in_minutes", nullable = false)
    private int periodDurationInMinutes;

    @Column(name = "number_of_breaks", nullable = false)
    private int numberOfBreaks;

    @Column(name = "day_type", nullable = false)
    private String dayType;       // "weekday" or "saturday"

    @Column(name = "total_hours", nullable = false)
    private double totalHours;            // per day

    @Column(name = "total_periods_week", nullable = false)
    private int totalPeriodsPerWeek;      // per week



    @JsonInclude(JsonInclude.Include.NON_NULL)
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(
            name = "break_details",
            joinColumns = @JoinColumn(name = "timetable_structure_id")
    )
    private List<BreakDetail> breakDetails;



    public TimetableStructure() {}

    // ─────────────── Standard getters & setters ─────────────────

    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }

    public LocalTime getStartTime() {
        return startTime;
    }
    public void setStartTime(LocalTime startTime) {
        this.startTime = startTime;
    }

    public LocalTime getEndTime() {
        return endTime;
    }
    public void setEndTime(LocalTime endTime) {
        this.endTime = endTime;
    }

    public int getNumberOfPeriods() {
        return numberOfPeriods;
    }
    public void setNumberOfPeriods(int numberOfPeriods) {
        this.numberOfPeriods = numberOfPeriods;
    }

    public int getPeriodDurationInMinutes() {
        return periodDurationInMinutes;
    }
    public void setPeriodDurationInMinutes(int periodDurationInMinutes) {
        this.periodDurationInMinutes = periodDurationInMinutes;
    }

    public int getNumberOfBreaks() {
        return numberOfBreaks;
    }
    public void setNumberOfBreaks(int numberOfBreaks) {
        this.numberOfBreaks = numberOfBreaks;
    }

    public String getDayType() {
        return dayType;
    }
    public void setDayType(String dayType) {
        this.dayType = dayType;
    }

    public List<BreakDetail> getBreakDetails() {
        return breakDetails;
    }
    public void setBreakDetails(List<BreakDetail> breakDetails) {
        this.breakDetails = breakDetails;
    }

    public double getTotalHours() {
        return totalHours;
    }

    public int getTotalPeriodsPerWeek() {
        return totalPeriodsPerWeek;
    }

    // ─────────────── Computed helpers ─────────────────

    /** How many days this covers: 5 if "weekday", else 1 */
    public int getDaysCovered() {
        return "weekday".equalsIgnoreCase(dayType) ? 5 : 1;
    }

    /** Total periods across the week */
    public int getWeeklyPeriods() {
        return numberOfPeriods * getDaysCovered();
    }

    /** Total instructional hours across the week */
    public double getWeeklyHours() {
        // we subtract breaks in recalcTotals, so this is per-day * daysCovered
        return totalHours * getDaysCovered();
    }

    // ─────────────── Lifecycle hook ─────────────────

    /**
     * Before saving or updating: recalc
     *  • totalHours = ((periods×duration) − sum(breaks)) / 60
     *  • totalPeriodsPerWeek = periods × daysCovered
     */
    @PrePersist
    @PreUpdate
    private void recalcTotals() {
        int breakMins = 0;
        if (breakDetails != null) {
            breakMins = breakDetails
                    .stream()
                    .mapToInt(BreakDetail::getDurationInMinutes)
                    .sum();
        }
        int instrMinutes = numberOfPeriods * periodDurationInMinutes ;
        this.totalHours = instrMinutes / 60.0;

        this.totalPeriodsPerWeek = getWeeklyPeriods();

    }
}
