package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.TimetableEntry;
import org.example.timetablegenerator.service.TimetableGeneratorService;
import org.example.timetablegenerator.repository.TimetableEntryRepository;
import org.example.timetablegenerator.repository.SectionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/timetable")
public class TimetableRestController {

    @Autowired
    private TimetableEntryRepository timetableRepo;

    @Autowired
    private TimetableGeneratorService generatorService;

    @Autowired
    private SectionRepository sectionRepo;

    // Generate and return timetable entries
    @PostMapping("/generate")
    public ResponseEntity<List<TimetableEntry>> generateTimetable(@RequestParam Long classId,
                                                                  @RequestParam Long sectionId) {
        try {
            List<TimetableEntry> existing = timetableRepo.findByClassAdd_IdAndSection_Id(classId, sectionId);

            if (!existing.isEmpty()) {
                System.out.printf("⏸️ Timetable already exists for classId = %d, sectionId = %d%n", classId, sectionId);
                return ResponseEntity.ok(existing);
            }

            System.out.printf("⚙️ Generating timetable for classId = %d, sectionId = %d%n", classId, sectionId);
            generatorService.generateTimetable();

            List<TimetableEntry> entries = timetableRepo.findByClassAdd_IdAndSection_Id(classId, sectionId);
            System.out.println("✅ Total entries for section: " + entries.size());

            return ResponseEntity.ok(entries);
        } catch (Exception e) {
            System.err.println("❌ Error generating timetable: " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }


    // Just fetch timetable (no regeneration)
    @GetMapping("/class/{classId}/section/{sectionId}")
    public ResponseEntity<List<TimetableEntry>> getTimetable(@PathVariable Long classId,
                                                             @PathVariable Long sectionId) {
        try {
            List<TimetableEntry> entries = timetableRepo.findByClassAdd_IdAndSection_Id(classId, sectionId);
            return ResponseEntity.ok(entries);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.emptyList());
        }
    }
}
