package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.BreakDetail;
import org.example.timetablegenerator.model.Slot;
import org.example.timetablegenerator.model.TimetableStructure;
import org.example.timetablegenerator.repository.TimetableStructureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Controller
public class TimetableLayoutController {

    @Autowired
    private TimetableStructureRepository timetableStructureRepository;

    @GetMapping("/timetable-layout")
    public String showTimetableLayout(Model model) {
        TimetableStructure weekdayStructure =
                timetableStructureRepository
                        .findByDayType("weekday")
                        .orElse(null);

        TimetableStructure saturdayStructure =
                timetableStructureRepository
                        .findByDayType("saturday")
                        .orElse(null);

        List<String> weekdays =
                Arrays.asList("Monday", "Tuesday", "Wednesday", "Thursday", "Friday");

        List<Slot> weekdaySlots =
                weekdayStructure == null
                        ? Collections.emptyList()
                        : generateSlots(weekdayStructure);

        List<Slot> saturdaySlots =
                saturdayStructure == null
                        ? Collections.emptyList()
                        : generateSlots(saturdayStructure);

        model.addAttribute("weekdays", weekdays);
        model.addAttribute("weekdaySlots", weekdaySlots);
        model.addAttribute("saturdaySlots", saturdaySlots);
        return "timetable-layout";
    }

    private List<Slot> generateSlots(TimetableStructure st) {
        List<Slot> slots = new ArrayList<>();
        LocalTime cur = st.getStartTime();
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("hh:mm a");

        // sort breaks
        List<BreakDetail> breaks = new ArrayList<>(st.getBreakDetails());
        breaks.sort(Comparator.comparing(BreakDetail::getBreakStartTime));

        int periodsRemaining = st.getNumberOfPeriods();
        int periodIndex = 1;
        int breakIndex = 0;

        while (periodsRemaining > 0) {
            // if it's exactly break time, insert break
            if (breakIndex < breaks.size()
                    && breaks.get(breakIndex).getBreakStartTime().equals(cur)) {

                BreakDetail bd = breaks.get(breakIndex);
                LocalTime end = cur.plusMinutes(bd.getDurationInMinutes());
                String label = bd.getDescription()
                        + " (" + cur.format(fmt)
                        + " – " + end.format(fmt) + ")";
                slots.add(new Slot(label, "break"));
                cur = end;
                breakIndex++;

            } else {
                // otherwise a normal period
                LocalTime end = cur.plusMinutes(st.getPeriodDurationInMinutes());
                String label = "Period " + periodIndex
                        + " (" + cur.format(fmt)
                        + " – " + end.format(fmt) + ")";
                slots.add(new Slot(label, "period"));
                cur = end;
                periodIndex++;
                periodsRemaining--;
            }
        }

        return slots;
    }
}