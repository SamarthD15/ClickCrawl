package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.BreakDetail;
import org.example.timetablegenerator.model.TimetableStructure;
import org.example.timetablegenerator.repository.TimetableStructureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

@Controller
public class TimetableStructureController {

    @Autowired
    private TimetableStructureRepository timetableStructureRepository;

    @GetMapping("/add-timetable-structure")
    public String showTimetableStructureForm(Model model) {
        return "add-timetable-structure";
    }

    @PostMapping("/add-timetable-structure")
    public String addTimetableStructure(
            @RequestParam @DateTimeFormat(pattern = "HH:mm") LocalTime startTime,
            @RequestParam @DateTimeFormat(pattern = "HH:mm") LocalTime endTime,
            @RequestParam String dayType,
            @RequestParam int numberOfPeriods,
            @RequestParam int periodDurationInMinutes,
            @RequestParam int numberOfBreaks,
            @RequestParam(required = false) List<String> breakDescriptions,
            @RequestParam(required = false) @DateTimeFormat(pattern = "HH:mm") List<LocalTime> breakStartTimes,
            @RequestParam(required = false) List<Integer> breakDurations,
            Model model
    ) {
        // Build the list of BreakDetail entries
        List<BreakDetail> breakDetails = new ArrayList<>();
        if (breakDescriptions != null && breakStartTimes != null && breakDurations != null) {
            for (int i = 0; i < breakDescriptions.size(); i++) {
                breakDetails.add(new BreakDetail(
                        breakDescriptions.get(i),
                        breakStartTimes.get(i),
                        breakDurations.get(i)
                ));
            }
        }

        // Assemble and save the TimetableStructure
        TimetableStructure structure = new TimetableStructure();
        structure.setStartTime(startTime);
        structure.setEndTime(endTime);
        structure.setDayType(dayType);                         // recalculates totalPeriodsPerWeek
        structure.setNumberOfPeriods(numberOfPeriods);         // recalculates both totalHours & totalPeriodsPerWeek
        structure.setPeriodDurationInMinutes(periodDurationInMinutes); // recalculates totalHours
        structure.setNumberOfBreaks(numberOfBreaks);
        structure.setBreakDetails(breakDetails);
        // no need to manually set totalHours or totalPeriodsPerWeek—they’re computed in your entity

        timetableStructureRepository.save(structure);

        model.addAttribute("successMessage", "Timetable structure saved successfully.");
        return "add-timetable-structure";
    }
}
