package org.example.timetablegenerator.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import com.fasterxml.jackson.annotation.JsonProperty;


@Entity
@Table(name = "teacher")
public class Teacher {


    @Id
    @Column(name = "t_id") // <-- This fixes the error
    private String tid;
    private String fullname;
    private String mobile_number;
    private String email;
    private String address;
    private String gender;
    private String bloodgroup;
    private String qualification; // <-- Added this line
    private String adhaarnumber;

    // Constructors
    public Teacher() {}

    public Teacher(String fullname, String mobile_number, String email,
                   String address, String gender, String bloodgroup, String qualification, String adhaarnumber) {
        this.fullname = fullname;
        this.mobile_number = mobile_number;
        this.email = email;
        this.address = address;
        this.gender = gender;
        this.bloodgroup = bloodgroup;
        this.qualification = qualification; // <-- Added
        this.adhaarnumber = adhaarnumber;
    }

    // Getters and Setters
     // <-- This fixes the error
    public String getTid() {
        return tid;
    }

    public void setT_id(String tid) {
        this.tid = tid;
    }
    @JsonProperty("fullname")
    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public String getQualification() { // <-- Added
        return qualification;
    }

    public void setQualification(String qualification) { // <-- Added
        this.qualification = qualification;
    }

    public String getAdhaarnumber() {
        return adhaarnumber;
    }

    public void setAdhaarnumber(String adhaarnumber) {
        this.adhaarnumber = adhaarnumber;
    }
}
