package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.Course;
import org.example.timetablegenerator.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
public class CourseController {

    @Autowired
    private CourseRepository courseRepository;

    @PostMapping("/register-course")
    public String registerCourse(Course course) {
        courseRepository.save(course);
        return "redirect:/course-registration-success?courseName=" + course.getCourse_name();
    }

    @GetMapping("/course-registration")
    public String showCourseForm() {
        return "course-registration";
    }

    @GetMapping("/course-registration-success")
    @ResponseBody
    public String successMessage(@RequestParam("courseName") String courseName) {
        return "<script>alert('Course \"" + courseName + "\" registered successfully!'); window.location.href='/course-registration';</script>";
    }

    @GetMapping("/courses")
    public String listCourses(Model model) {
        model.addAttribute("courses", courseRepository.findAll());
        return "courses";   // resolves to src/main/resources/templates/courses.html
    }

    // Show edit form pre-filled with course data
    @GetMapping("/courses/edit/{code}")
    public String showEditForm(@PathVariable("code") String code, Model model) {
        Optional<Course> courseOpt = courseRepository.findById(code);
        if (courseOpt.isPresent()) {
            model.addAttribute("course", courseOpt.get());
            return "course-edit"; // name of the edit HTML template (course-edit.html)
        } else {
            // course not found, redirect back to list
            return "redirect:/courses";
        }
    }

    // Handle form submission for course update
    @PostMapping("/courses/edit/{code}")
    public String updateCourse(@PathVariable("code") String code, Course updatedCourse) {
        // Just save the updated course - since course_code is PK and readonly, no PK change possible
        courseRepository.save(updatedCourse);
        return "redirect:/courses";
    }

    // --- Delete course ---
    @GetMapping("/courses/delete/{code}")
    public String deleteCourse(@PathVariable("code") String courseCode, RedirectAttributes redirectAttributes) {
        try {
            courseRepository.deleteById(courseCode);
            redirectAttributes.addFlashAttribute("message", "Course deleted successfully!");
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "Course is still assigned to one or more teachers and cannot be deleted.");
        }
        return "redirect:/courses";
    }
}
