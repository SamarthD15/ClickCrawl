// src/main/java/org/example/timetablegenerator/controller/ClassAddController.java
package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.ClassAdd;
import org.example.timetablegenerator.model.ClassCourse;
import org.example.timetablegenerator.model.Course;
import org.example.timetablegenerator.model.Section;
import org.example.timetablegenerator.repository.ClassAddRepository;
import org.example.timetablegenerator.repository.CourseRepository;
import org.example.timetablegenerator.repository.SectionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.*;

@Controller
public class ClassAddController {

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private ClassAddRepository classAddRepository;

    @Autowired
    private SectionRepository sectionRepository;

    @GetMapping("/add-class")
    public String showAddClassForm(Model model) {
        // fetch core and elective lists
        List<Course> coreCourses     = courseRepository.findByCourseType("Core");
        List<Course> electiveCourses = courseRepository.findByCourseType("Elective");

        model.addAttribute("coreCourses", coreCourses);
        model.addAttribute("electiveCourses", electiveCourses);

        return "add-class";
    }

    @PostMapping("/add-class")
    public String addClass(
            @RequestParam("className") String className,
            @RequestParam("selectedCourseCodes") List<String> selectedCodes,
            @RequestParam Map<String,String> allParams,
            RedirectAttributes redirectAttributes
    ) {
        ClassAdd newClass = new ClassAdd();
        newClass.setClassName(className);

        int total = 0;
        List<ClassCourse> entries = new ArrayList<>();

        for (String code : selectedCodes) {
            String param = "weeklyHours__" + code;
            int hrs = 0;
            try {
                hrs = Integer.parseInt(allParams.getOrDefault(param, "0"));
            } catch (NumberFormatException e) { /* leave hrs = 0 */ }

            total += hrs;
            entries.add(new ClassCourse(code, hrs));
        }

        newClass.setWeeklyHours(total);
        newClass.setCourses(entries);
        classAddRepository.save(newClass);

        redirectAttributes.addFlashAttribute("successMessage", "Class added successfully!");
        return "redirect:/add-class";
    }

    // REST endpoint for frontend dropdown
    @GetMapping("/api/classes")
    @ResponseBody
    public List<String> getClassNames() {
        return classAddRepository.findAll()
                .stream()
                .map(ClassAdd::getClassName)
                .distinct()
                .toList();
    }
}