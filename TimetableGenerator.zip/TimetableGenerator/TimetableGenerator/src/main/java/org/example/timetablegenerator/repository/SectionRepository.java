package org.example.timetablegenerator.repository;

import org.example.timetablegenerator.model.ClassAdd;
import org.example.timetablegenerator.model.Section;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SectionRepository extends JpaRepository<Section, Long> {
    List<Section> findByClassAdd_Id(Long classId);
    Optional<Section> findBySectionNameAndClassAdd(String sectionName, ClassAdd classAdd);

}

