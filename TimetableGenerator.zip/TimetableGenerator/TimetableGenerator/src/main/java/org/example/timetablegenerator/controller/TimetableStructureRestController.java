package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.TimetableStructure;
import org.example.timetablegenerator.repository.TimetableStructureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/structure")
public class TimetableStructureRestController {

    @Autowired
    private TimetableStructureRepository repo;

    @GetMapping("/{dayType}")
    public ResponseEntity<TimetableStructure> getByDayType(@PathVariable String dayType) {
        return repo.findByDayType(dayType)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
