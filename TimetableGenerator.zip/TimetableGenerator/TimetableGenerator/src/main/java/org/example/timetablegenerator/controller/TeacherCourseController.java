package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.Course;
import org.example.timetablegenerator.model.Teacher;
import org.example.timetablegenerator.model.TeacherCourse;
import org.example.timetablegenerator.repository.CourseRepository;
import org.example.timetablegenerator.repository.TeacherCourseRepository;
import org.example.timetablegenerator.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class TeacherCourseController {
    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private TeacherCourseRepository teacherCourseRepository;

    @GetMapping("/teacher-course-mapping")
    public String showMappingForm(Model model) {
        model.addAttribute("teachers", teacherRepository.findAll());
        model.addAttribute("courses",   courseRepository.findAll());
        return "teacher-course-mapping";
    }

    @PostMapping("/map-teacher-to-course")
    public String mapTeacherToCourse(
            @RequestParam("teacherId") String teacherId,
            @RequestParam(value = "courseCodes", required = false) List<String> courseCodes,
            RedirectAttributes redirectAttributes
    ) {
        if (courseCodes == null || courseCodes.isEmpty()) {
            redirectAttributes.addFlashAttribute("message",
                    "Please select at least one course to map.");
            return "redirect:/teacher-course-mapping";
        }

        try {
            Teacher teacher = teacherRepository.findById(teacherId)
                    .orElseThrow(() -> new IllegalArgumentException("Invalid teacher ID"));

            // Map each selected course
            for (String code : courseCodes) {
                Course course = courseRepository.findById(code)
                        .orElseThrow(() -> new IllegalArgumentException("Invalid course code: " + code));
                TeacherCourse mapping = new TeacherCourse();
                mapping.setTeacher(teacher);
                mapping.setCourse(course);
                teacherCourseRepository.save(mapping);
            }

            redirectAttributes.addFlashAttribute("message",
                    "Successfully mapped teacher to " + courseCodes.size() + " course(s).");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("message", "Error: " + e.getMessage());
        }

        return "redirect:/teacher-course-mapping";
    }
}
