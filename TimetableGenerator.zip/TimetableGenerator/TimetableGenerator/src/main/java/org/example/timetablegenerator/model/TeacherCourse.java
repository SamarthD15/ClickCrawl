package org.example.timetablegenerator.model;

import jakarta.persistence.*;


@Entity
public class TeacherCourse {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "t_id")
    private Teacher teacher;


    @ManyToOne
    @JoinColumn(
            name = "course_code",
            referencedColumnName = "course_code"
    )
    private Course course;



    // Getter and Setter for id
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    // Getter and Setter for teacher
    public Teacher getTeacher() {
        return teacher;
    }

    public void setTeacher(Teacher teacher) {
        this.teacher = teacher;
    }

    // Getter and Setter for course
    public Course getCourse() {
        return course;
    }

    public void setCourse(Course course) {
        this.course = course;
    }


}
