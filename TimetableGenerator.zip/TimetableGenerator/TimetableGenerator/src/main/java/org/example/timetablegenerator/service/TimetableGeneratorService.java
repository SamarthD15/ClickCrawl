package org.example.timetablegenerator.service;

import org.example.timetablegenerator.model.*;
import org.example.timetablegenerator.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class TimetableGeneratorService {

    @Autowired private SectionRepository sectionRepo;
    @Autowired private TeacherCourseRepository teacherCourseRepo;
    @Autowired private TimetableStructureRepository structureRepo;
    @Autowired private TimetableEntryRepository timetableRepo;
    @Autowired private CourseRepository courseRepo;

    public void generateTimetable() {
        timetableRepo.deleteAll();

        TimetableStructure weekdayStructure = structureRepo.findByDayType("weekday")
                .orElseThrow(() -> new RuntimeException("No weekday structure found"));

        TimetableStructure saturdayStructure = structureRepo.findByDayType("saturday")
                .orElseThrow(() -> new RuntimeException("No saturday structure found"));

        List<String> weekdays = Arrays.asList("Monday", "Tuesday", "Wednesday", "Thursday", "Friday");
        List<String> allDays = new ArrayList<>(weekdays);
        allDays.add("Saturday");

        Map<String, Map<Integer, Set<String>>> teacherAssignments = new HashMap<>();
        Map<String, Map<Integer, Set<String>>> courseAssignments = new HashMap<>();

        for (Section section : sectionRepo.findAll()) {
            ClassAdd classAdd = section.getClassAdd();
            List<ClassCourse> classCourses = classAdd.getCourses();

            List<SlotAssignment> allSlots = new ArrayList<>();
            for (String day : allDays) {
                int periodCount = day.equals("Saturday") ? saturdayStructure.getNumberOfPeriods() : weekdayStructure.getNumberOfPeriods();
                for (int p = 1; p <= periodCount; p++) {
                    allSlots.add(new SlotAssignment(day, p));
                }
            }

            Collections.shuffle(allSlots);

            Map<String, Integer> hoursRemaining = new HashMap<>();
            for (ClassCourse cc : classCourses) {
                hoursRemaining.put(cc.getCourseCode(), cc.getWeeklyHours());
            }

            Map<String, Map<String, Integer>> dailyCourseCount = new HashMap<>();
            Map<String, Integer> maxHoursMap = new HashMap<>();
            int maxHours = classCourses.stream().mapToInt(ClassCourse::getWeeklyHours).max().orElse(0);

            Map<String, String> courseTypes = new HashMap<>();
            for (ClassCourse cc : classCourses) {
                Course course = courseRepo.findById(cc.getCourseCode()).orElse(null);
                if (course != null) {
                    maxHoursMap.put(cc.getCourseCode(), cc.getWeeklyHours());
                    courseTypes.put(cc.getCourseCode(), course.getCourse_type());
                }
            }

            for (SlotAssignment slot : allSlots) {
                boolean assigned = false;

                List<String> shuffledCourses = new ArrayList<>(hoursRemaining.keySet());
                shuffledCourses.sort((a, b) -> hoursRemaining.get(b) - hoursRemaining.get(a));

                for (String courseCode : shuffledCourses) {
                    int hrsLeft = hoursRemaining.getOrDefault(courseCode, 0);
                    if (hrsLeft <= 0) continue;

                    dailyCourseCount.putIfAbsent(courseCode, new HashMap<>());
                    int countToday = dailyCourseCount.get(courseCode).getOrDefault(slot.day, 0);

                    boolean isMaxHour = maxHoursMap.get(courseCode) == maxHours;
                    if (!isMaxHour && countToday >= 1) continue;
                    if (isMaxHour && countToday >= 2) continue;

                    List<TeacherCourse> teachers = teacherCourseRepo.findByCourseCode(courseCode);
                    Collections.shuffle(teachers);
                    if (teachers.isEmpty()) continue;

                    for (TeacherCourse tc : teachers) {
                        Teacher teacher = tc.getTeacher();
                        Course course = courseRepo.findById(courseCode).orElse(null);
                        if (course == null) continue;

                        teacherAssignments.putIfAbsent(slot.day, new HashMap<>());
                        courseAssignments.putIfAbsent(slot.day, new HashMap<>());
                        teacherAssignments.get(slot.day).putIfAbsent(slot.period, new HashSet<>());
                        courseAssignments.get(slot.day).putIfAbsent(slot.period, new HashSet<>());

                        Set<String> teachersUsed = teacherAssignments.get(slot.day).get(slot.period);
                        Set<String> coursesUsed = courseAssignments.get(slot.day).get(slot.period);

                        if (teachersUsed.contains(teacher.getTid()) || coursesUsed.contains(courseCode)) {
                            continue;
                        }

                        TimetableEntry entry = new TimetableEntry();
                        entry.setClassAdd(classAdd);
                        entry.setSection(section);
                        entry.setDayOfWeek(slot.day);
                        entry.setPeriodNumber(slot.period);
                        entry.setCourse(course);
                        entry.setTeacher(teacher);

                        timetableRepo.save(entry);

                        teachersUsed.add(teacher.getTid());
                        coursesUsed.add(courseCode);

                        hoursRemaining.put(courseCode, hrsLeft - 1);
                        dailyCourseCount.get(courseCode).put(slot.day, countToday + 1);
                        assigned = true;
                        break;
                    }

                    if (assigned) break;
                }

                // 🔁 Try again without per-day limit if still not assigned
                if (!assigned) {
                    for (String courseCode : shuffledCourses) {
                        int hrsLeft = hoursRemaining.getOrDefault(courseCode, 0);
                        if (hrsLeft <= 0) continue;

                        List<TeacherCourse> teachers = teacherCourseRepo.findByCourseCode(courseCode);
                        Collections.shuffle(teachers);
                        if (teachers.isEmpty()) continue;

                        for (TeacherCourse tc : teachers) {
                            Teacher teacher = tc.getTeacher();
                            Course course = courseRepo.findById(courseCode).orElse(null);
                            if (course == null) continue;

                            teacherAssignments.putIfAbsent(slot.day, new HashMap<>());
                            courseAssignments.putIfAbsent(slot.day, new HashMap<>());
                            teacherAssignments.get(slot.day).putIfAbsent(slot.period, new HashSet<>());
                            courseAssignments.get(slot.day).putIfAbsent(slot.period, new HashSet<>());

                            Set<String> teachersUsed = teacherAssignments.get(slot.day).get(slot.period);
                            Set<String> coursesUsed = courseAssignments.get(slot.day).get(slot.period);

                            if (teachersUsed.contains(teacher.getTid()) || coursesUsed.contains(courseCode)) {
                                continue;
                            }

                            TimetableEntry entry = new TimetableEntry();
                            entry.setClassAdd(classAdd);
                            entry.setSection(section);
                            entry.setDayOfWeek(slot.day);
                            entry.setPeriodNumber(slot.period);
                            entry.setCourse(course);
                            entry.setTeacher(teacher);

                            timetableRepo.save(entry);

                            teachersUsed.add(teacher.getTid());
                            coursesUsed.add(courseCode);

                            hoursRemaining.put(courseCode, hrsLeft - 1);
                            assigned = true;
                            break;
                        }
                        if (assigned) break;
                    }
                }

                if (!assigned) {
                    System.out.printf("⚠️ Could not assign any class for %s %s → %s %d%n",
                            classAdd.getClassName(), section.getSectionName(), slot.day, slot.period);
                }
            }
        }
    }

    private static class SlotAssignment {
        String day;
        int period;

        SlotAssignment(String day, int period) {
            this.day = day;
            this.period = period;
        }
    }
}
