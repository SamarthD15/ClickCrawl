package org.example.timetablegenerator.repository;

import org.example.timetablegenerator.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Admin, String> {
    Admin findByUsername(String username); // works since username is PK
}
