// src/main/java/org/example/timetablegenerator/model/ClassCourse.java
package org.example.timetablegenerator.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;

@Embeddable
public class ClassCourse {
    @Column(name = "course_code", nullable = false)
    private String courseCode;

    @Column(name = "weekly_hours", nullable = false)
    private int weeklyHours;

    public ClassCourse() {}

    public ClassCourse(String courseCode, int weeklyHours) {
        this.courseCode  = courseCode;
        this.weeklyHours = weeklyHours;
    }

    public String getCourseCode() {
        return courseCode;
    }
    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public int getWeeklyHours() {
        return weeklyHours;
    }
    public void setWeeklyHours(int weeklyHours) {
        this.weeklyHours = weeklyHours;
    }
}
