package org.example.timetablegenerator.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TimetablePageController {

    @GetMapping("/tt")
    public String showTimetablePage() {
        return "tt"; // This returns src/main/resources/templates/tt.html
    }
}
