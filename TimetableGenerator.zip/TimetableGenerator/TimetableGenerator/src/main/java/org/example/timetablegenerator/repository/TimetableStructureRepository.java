package org.example.timetablegenerator.repository;

import org.example.timetablegenerator.model.TimetableStructure;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TimetableStructureRepository
        extends JpaRepository<TimetableStructure, Long> {

    Optional<TimetableStructure> findByDayType(String dayType);
}
