package org.example.timetablegenerator.model;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.time.LocalTime;

@Embeddable
public class BreakDetail {

    @Column(nullable = false)
    private String description;

    @Column(name = "break_start_time", nullable = false)
    private LocalTime breakStartTime;

    @Column(name = "duration_in_minutes", nullable = false)
    private int durationInMinutes;

    public BreakDetail() {}

    public BreakDetail(String description, LocalTime breakStartTime, int durationInMinutes) {
        this.description = description;
        this.breakStartTime = breakStartTime;
        this.durationInMinutes = durationInMinutes;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalTime getBreakStartTime() {
        return breakStartTime;
    }

    public void setBreakStartTime(LocalTime breakStartTime) {
        this.breakStartTime = breakStartTime;
    }

    public int getDurationInMinutes() {
        return durationInMinutes;
    }

    public void setDurationInMinutes(int durationInMinutes) {
        this.durationInMinutes = durationInMinutes;
    }

    /** Convenience: end = start + duration */
    public LocalTime getEndTime() {
        return breakStartTime.plusMinutes(durationInMinutes);
    }
}
