package org.example.timetablegenerator.repository;

import org.example.timetablegenerator.model.ClassAdd;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;


@Repository
public interface ClassAddRepository extends JpaRepository<ClassAdd, Long> {
    Optional<ClassAdd> findByClassName(String className); // ✅ Clean and correct
}
