package org.example.timetablegenerator.model;

public class Slot {
    private final String label;
    private final String type; // "period" or "break"

    public Slot(String label, String type) {
        this.label = label;
        this.type  = type;
    }
    public String getLabel() { return label; }
    public String getType()  { return type;  }
}
