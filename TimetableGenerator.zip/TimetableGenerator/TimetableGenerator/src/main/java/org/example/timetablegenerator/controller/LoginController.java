package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.Admin;
import org.example.timetablegenerator.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    @Autowired
    private AdminRepository adminRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/admin/login")
    public String showLoginForm() {
        return "admin-login";
    }

    @PostMapping("/admin/login")
    public String processLogin(@RequestParam String username,
                               @RequestParam String password,
                               Model model) {
        Admin admin = adminRepository.findById(username).orElse(null);

        if (admin != null && passwordEncoder.matches(password, admin.getPassword())) {
            return "redirect:/dashboard";
        } else {
            model.addAttribute("error", "Invalid username or password");
            return "admin-login";
        }
    }

    @GetMapping("/admin/dashboard")
    public String showDashboard() {
        return "dashboard";
    }
}
