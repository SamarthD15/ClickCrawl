package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.*;
import org.example.timetablegenerator.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.*;
import java.util.stream.Collectors;

@Controller
public class TeacherTimetableController {

    @Autowired
    private TimetableEntryRepository timetableEntryRepository;

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private ClassAddRepository classAddRepository;

    @Autowired
    private SectionRepository sectionRepository;

    @GetMapping("/select-teacher")
    public String showTeacherSelect(Model model) {
        model.addAttribute("teachers", teacherRepository.findAll());
        return "select-teacher";
    }

    @GetMapping("/select-class-section")
    public String showClassSectionOptions(@RequestParam("tId") String teacherId, Model model) {
        Teacher teacher = teacherRepository.findById(teacherId).orElse(null);
        if (teacher == null) return "redirect:/select-teacher";

        List<TimetableEntry> entries = timetableEntryRepository.findByTeacher_Tid(teacherId);

        Set<String> classSectionKeys = new LinkedHashSet<>();
        Map<String, String> labelMap = new LinkedHashMap<>();

        for (TimetableEntry entry : entries) {
            Long classId = entry.getClassAdd().getId();
            Long sectionId = entry.getSection().getId();
            String key = classId + "-" + sectionId;
            if (!classSectionKeys.contains(key)) {
                String label = entry.getClassAdd().getClassName() + " - " + entry.getSection().getSectionName();
                classSectionKeys.add(key);
                labelMap.put(key, label);
            }
        }

        model.addAttribute("teacher", teacher);
        model.addAttribute("combinations", labelMap);
        return "select-class-section";
    }

    @GetMapping("/teacher-timetable/view")
    public String showTeacherTimetable(@RequestParam("tId") String teacherId,
                                       @RequestParam("classId") Long classId,
                                       @RequestParam("sectionId") Long sectionId,
                                       Model model) {
        Teacher teacher = teacherRepository.findById(teacherId).orElse(null);
        if (teacher == null) return "redirect:/select-teacher";

        List<TimetableEntry> entries = timetableEntryRepository.findByTeacher_Tid(teacherId).stream()
                .filter(e -> e.getClassAdd().getId().equals(classId) && e.getSection().getId().equals(sectionId))
                .collect(Collectors.toList());

        List<String> days = Arrays.asList("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
        int maxPeriod = entries.stream().mapToInt(TimetableEntry::getPeriodNumber).max().orElse(8);

        Map<String, Map<Integer, String>> timetable = new LinkedHashMap<>();
        for (String day : days) {
            Map<Integer, String> map = new LinkedHashMap<>();
            for (int i = 1; i <= maxPeriod; i++) map.put(i, "-");
            timetable.put(day, map);
        }

        for (TimetableEntry entry : entries) {
            String day = normalizeDay(entry.getDayOfWeek());
            int period = entry.getPeriodNumber();
            String label = entry.getCourse().getCourse_name();
            if (timetable.containsKey(day)) timetable.get(day).put(period, label);
        }

        model.addAttribute("teacher", teacher);
        model.addAttribute("days", days);
        model.addAttribute("timetable", timetable);
        model.addAttribute("maxPeriod", maxPeriod);

        System.out.println("Days: " + days);
        System.out.println("Max Period: " + maxPeriod);
        System.out.println("Timetable keys: " + timetable.keySet());
        System.out.println("Example: " + timetable.get("Monday"));

        return "teacher-timetable-view";
    }

    private String normalizeDay(String input) {
        if (input == null) return "";
        input = input.trim().toLowerCase();
        switch (input) {
            case "monday": return "Monday";
            case "tuesday": return "Tuesday";
            case "wednesday": return "Wednesday";
            case "thursday": return "Thursday";
            case "friday": return "Friday";
            case "saturday": return "Saturday";
            default: return input;
        }
    }
}
