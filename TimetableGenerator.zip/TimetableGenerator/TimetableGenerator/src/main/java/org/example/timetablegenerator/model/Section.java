package org.example.timetablegenerator.model;

import jakarta.persistence.*;

@Entity
@Table(name = "sections")
public class Section {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String sectionName;

    @ManyToOne
    @JoinColumn(name = "class_id")
    private ClassAdd classAdd;  // Link to your ClassAdd entity

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSectionName() {
        return sectionName;
    }

    public void setSectionName(String sectionName) {
        this.sectionName = sectionName;
    }

    public ClassAdd getClassAdd() {
        return classAdd;
    }

    public void setClassAdd(ClassAdd classAdd) {
        this.classAdd = classAdd;
    }
}
