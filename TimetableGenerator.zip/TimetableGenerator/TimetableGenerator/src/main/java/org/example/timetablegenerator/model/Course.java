package org.example.timetablegenerator.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "courses")
public class Course {

    @Id
    @Column(name = "course_code")
    private String course_code;

    @Column(name = "course_name")
    private String course_name;

    @Column(name = "course_type")
    private String course_type;

    // Constructors
    public Course() {}

    public Course(String course_code, String course_name, String course_type) {
        this.course_code = course_code;
        this.course_name = course_name;
        this.course_type = course_type;
    }

    // Getters & setters
    public String getCourse_code() {
        return course_code;
    }

    public void setCourse_code(String course_code) {
        this.course_code = course_code;
    }

    @JsonProperty("courseName")
    public String getCourse_name() {
        return course_name;
    }

    public void setCourse_name(String course_name) {
        this.course_name = course_name;
    }

    public String getCourse_type() {
        return course_type;
    }

    public void setCourse_type(String course_type) {
        this.course_type = course_type;
    }
}
