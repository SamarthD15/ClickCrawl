package org.example.timetablegenerator.controller;

import org.example.timetablegenerator.model.Teacher;
import org.example.timetablegenerator.model.TeacherCourse;
import org.example.timetablegenerator.repository.CourseRepository;
import org.example.timetablegenerator.repository.TeacherCourseRepository;
import org.example.timetablegenerator.repository.TeacherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
public class TeacherController {

    @Autowired
    private TeacherRepository teacherRepository;

    @Autowired
    private CourseRepository courseRepository;

    @GetMapping("/teacher-login")
    public String showTeacherLoginPage() {
        return "teacher-login"; // Make sure this HTML file exists in /templates
    }

    // ✅ NOT STATIC
    private String generateTeacherId() {
        long count = teacherRepository.count();
        String newId;
        do {
            newId = "TCH_" + (++count);
        } while (teacherRepository.existsById(newId));
        return newId;
    }


    @GetMapping("/dashboard")
    public String showDashboard() {
        return "dashboard"; // matches dashboard.html (case-sensitive!)
    }
    @GetMapping("/teacher-registration")
    public String showTeacherRegistrationPage(Model model) {
        model.addAttribute("teacher", new Teacher()); // Empty teacher object for the form
        return "teacher-registration"; // Make sure this matches the name of your HTML file
    }


    // ✅ NOT STATIC
    @PostMapping("/register-teacher")
    public String registerTeacher(@ModelAttribute Teacher teacher, Model model) {
        teacher.setT_id(generateTeacherId()); // <-- set the t_id explicitly
        teacherRepository.save(teacher);
        model.addAttribute("message", "Teacher registered successfully!");
        model.addAttribute("t_id", teacher.getTid());  // Pass the t_id to the view
        return "teacher-registration";  // Return the view name
    }

    @GetMapping("/teachers")
    public String listTeachers(Model model) {
        List<Teacher> teachers = teacherRepository.findAll();
        model.addAttribute("teachers", teachers);
        return "teachers";
    }

    @GetMapping("/edit-teacher/{id}")
    public String editTeacher(@PathVariable("id") String id, Model model) {
        Optional<Teacher> teacherOptional = teacherRepository.findById(id);
        if (teacherOptional.isPresent()) {
            model.addAttribute("teacher", teacherOptional.get());
            return "edit-teacher";
        } else {
            return "redirect:/teachers";
        }
    }

    @PostMapping("/update-teacher/{id}")
    public String updateTeacher(@PathVariable("id") String id, @ModelAttribute Teacher updatedTeacher) {
        updatedTeacher.setT_id(id);  // ✅ Fixed the method name
        teacherRepository.save(updatedTeacher);
        return "redirect:/teachers";
    }

    @GetMapping("/delete-teacher/{id}")
    public String deleteTeacher(@PathVariable("id") String teacherId, RedirectAttributes redirectAttributes) {
        try {
            teacherRepository.deleteById(teacherId);
            redirectAttributes.addFlashAttribute("message", "Teacher deleted successfully!");
        } catch (DataIntegrityViolationException e) {
            redirectAttributes.addFlashAttribute("error", "Teacher is still assigned to one or more courses and cannot be deleted.");
        }
        return "redirect:/teachers";
    }
}
