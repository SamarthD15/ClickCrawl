package org.example.timetablegenerator.repository;

import org.example.timetablegenerator.model.Section;
import org.example.timetablegenerator.model.TimetableEntry;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TimetableEntryRepository extends JpaRepository<TimetableEntry, Long> {

    List<TimetableEntry> findByClassAdd_IdAndSection_Id(Long classId, Long sectionId);

    List<TimetableEntry> findByTeacher_Tid(String teacherId); // ✅ Correct
    Optional<TimetableEntry> findBySectionAndDayOfWeekAndPeriodNumber(Section section, String dayOfWeek, int periodNumber);

    ;
}
