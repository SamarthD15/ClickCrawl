package org.example.timetablegenerator.repository;

import org.example.timetablegenerator.model.TeacherCourse;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface TeacherCourseRepository extends JpaRepository<TeacherCourse, Long> {

    /**
     * Uses a hand-written JPQL to reference the entity field "course_code" directly,
     * without renaming your Java property.
     */
    @Query("SELECT tc FROM TeacherCourse tc WHERE tc.course.course_code = :code")
    List<TeacherCourse> findByCourseCode(@Param("code") String code);



}
