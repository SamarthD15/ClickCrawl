// src/main/java/org/example/timetablegenerator/model/ClassAdd.java
package org.example.timetablegenerator.model;

import jakarta.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "class_add")
public class ClassAdd {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "class_name", nullable = false)
    private String className;  // ✅ Renamed field

    @Column(name = "weekly_hours", nullable = false)
    private int weeklyHours;

    @ElementCollection
    @CollectionTable(
            name = "class_courses",
            joinColumns = @JoinColumn(name = "class_id")
    )
    private List<ClassCourse> courses = new ArrayList<>();

    // getters and setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getClassName() { return className; }
    public void setClassName(String className) { this.className = className; }

    public int getWeeklyHours() { return weeklyHours; }
    public void setWeeklyHours(int weeklyHours) { this.weeklyHours = weeklyHours; }

    public List<ClassCourse> getCourses() { return courses; }
    public void setCourses(List<ClassCourse> courses) { this.courses = courses; }
}
