package org.example.timetablegenerator;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TimetableGeneratorApplicationTests {

	@Test
	void contextLoads() {
	}

}
